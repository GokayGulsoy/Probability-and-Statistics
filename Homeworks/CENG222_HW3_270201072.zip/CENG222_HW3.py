import numpy as np
from matplotlib import pyplot as plt
# STUDENT NAME: GÖKAY GÜLSOY 
# STUDENT NO: 270201072

# Part a (Inverse Transform Method)
U = []
Xa = []
av_Xa = []
vr_Xa = []

# Populate the given arrays.
### YOUR CODE HERE ###

# calculating the updated average of x
def calc_average(av_Xa, Xa):
    # if list is empty average is equal to,
    # first element added to list 
    if len(av_Xa) == 0:
        av_Xa.append(Xa[0])

    else:
        total = 0
        # calculating the updated average   
        for i in range(0, len(Xa)):
            total += Xa[i]

        av_Xa.append(total / len(Xa))

# calculating the variance of X
def calc_variance(vr_Xa, Xa, av_Xa):
    # if there is only one element in Xa list
    # variance is equal to 0 
    if len(Xa) == 1:
        vr_Xa.append(0)

    else:
        total = 0
        # calculating the updated variance
        for i in range(0, len(Xa)):
            total += (Xa[i] - av_Xa[len(av_Xa) - 1]) ** 2

        # dividing by N (total number of elements)
        vr_Xa.append(total / len(Xa))


for i in range(0, 50000):
    u = np.random.rand()
    x = u ** (0.5)

    U.append(u)
    Xa.append(x)

    # computing the updated average 
    calc_average(av_Xa, Xa)
    # computing the updated variance
    calc_variance(vr_Xa, Xa, av_Xa)

# Inspect the following plots.
plt.figure()
for i in range(len(Xa)):
    plt.plot([Xa[i], U[i]], [1, 1.2])
plt.figure()
hU = plt.hist(U, 100, alpha=0.5, density=True)
hXa = plt.hist(Xa, 100, alpha=0.5, density=True)
plt.figure()
plt.plot(np.cumsum(hU[0]))
plt.plot(np.cumsum(hXa[0]))

# Plot the average and variance values.
### YOUR CODE HERE ###

plt.figure()
plt.plot(av_Xa)
plt.plot(vr_Xa)

# Part b (Rejection Method)
Xb = []
av_Xb = []
vr_Xb = []

# Populate the given arrays.
### YOUR CODE HERE ###

# let a = 1,b = 2,and c = 10
# such that 0 <= f(x) <= c for all x a <= x <= b

a,b,c = 1,2,10
i = 1

while ( i <= 50000):
    u = np.random.rand()
    v = np.random.rand()

    x = a+(b-a)*u
    y = c*v

    # rejection case
    if (y > x):
        continue
    else:
        Xb.append(x)
        calc_average(av_Xb,Xb)
        calc_variance(vr_Xb,Xb,av_Xb)
        i += 1

# Inspect the following plots.
plt.figure()
hXb = plt.hist(Xb,100,density = True)
plt.figure()
plt.plot(np.cumsum(hXb[0]))

# Plot the average and variance values.
### YOUR CODE HERE ###
plt.figure()
plt.plot(av_Xb)
plt.plot(vr_Xb)

plt.show()

