import numpy as np
from matplotlib import pyplot as plt
# Student name: GÖKAY GÜLSOY
# Student ID: 270201072

# calculate_MoM function calculates the Method of moments estimate
# for parameter theta

def calculate_MoM(X):
    total = 0

    for i in X:
        total += i

    average = total / len(X)
    theta = average / 2
    return theta


# calculate_MLE function calculates the Maximum liklehood estimation
# for parameter theta

def calculate_MLE(X):
    # to maximize the f(x)
    # returns the minimum value in the sample
    return min(X)


# function for calculating the estimator values
def calculate_estimators(population_list, N):
    sample_list = []

    for i in range(0, 100000):
        any_sample = []
        for j in range(0, N):
            random_indice = np.random.randint(0, len(population_list))
            any_sample.append(population_list[random_indice])

        sample_list.append(any_sample)

    # creating lists to hold MoM and MLE values for each sample
    MoM_list = []
    MLE_list = []

    for i in sample_list:
        MoM_list.append(calculate_MoM(i))
        MLE_list.append(calculate_MLE(i))

    # at the end of the for loop we will have populated the MoM list and MLE list
    # printing their histograms
    plt.figure()
    plt.hist(MoM_list, bins=np.linspace(0, 4.8, 100), alpha=0.5, density=True)
    plt.hist(MLE_list, bins=np.linspace(0, 4.8, 100), alpha=0.5, density=True)

    # adding legend to histogram plots
    txt1 = "MoM estimate histogram for N = {}"
    legend_output1 = txt1.format(N)
    txt2 = "MLE estimate histogram for N = {}"
    legend_output2 = txt2.format(N)
    plt.legend([legend_output1, legend_output2], loc="upper right")

    mean_and_variance_list = []
    # storing mean and variance of each estimator
    mean_and_variance_list.append(np.mean(MoM_list))
    mean_and_variance_list.append(np.var(MoM_list))

    mean_and_variance_list.append(np.mean(MLE_list))
    mean_and_variance_list.append(np.var(MLE_list))

    return mean_and_variance_list


# calculating MoM and MLE estimate for sample set
X = [0.3, 0.6, 0.8, 0.9]

mom_estimate = calculate_MoM(X)
mle_estimate = calculate_MLE(X)

print("Method of moments estimate for sample set X is: ", mom_estimate)
print("Method of maximum liklehood estimate for sample set X is: ", mle_estimate)

# populating pdf list for ploting it
pdf_y_list = []
pdf_x_list = []
for i in range(2,21):
    # in the sample output plot of pdf starts from 2.5 in x axes
    if i < 2.5:
        continue

    value = 2 * (2.4)** 2 / (i ** 3)
    pdf_x_list.append(i)

    pdf_y_list.append(value)

# after applying inverse tranform method we get the function
# F(x) = 2.4 / (x)**(0.5)

# generating a population of size 10 million
population_list = []

for i in range(0, 1000000):
    random_var = np.random.rand()
    random_var_distribution = 2.4 / random_var ** (0.5)

    population_list.append(random_var_distribution)
    
plt.plot(pdf_x_list,pdf_y_list)
#plt.hist(population_list,bins=100,density = True)
plt.legend(["PDF", "Histogram"], loc="upper right")

# at the end of the for loop we will have populated our
# population list
# calling the calculate_estimators function with N = [1,2,3,4,5,10,50,100,500,1000]

N = [1, 2, 3, 4, 5, 10, 50, 100, 500, 1000]

for i in N:
    mean_and_variance_list = calculate_estimators(population_list, i)
    print("For N = ", i, ":")

    output1 = "MoM estimate mean is: {:.3f}\t\tMoM estimate variance is: {:.3f}"
    output2 = "MLE estimate mean is: {:.3f}\t\tMLE estimate variance is: {:.3f}"
    print(output1.format(mean_and_variance_list[0], mean_and_variance_list[1]))
    print(output2.format(mean_and_variance_list[2], mean_and_variance_list[3]))

plt.show()

