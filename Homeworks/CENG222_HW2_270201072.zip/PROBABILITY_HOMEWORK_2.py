from matplotlib import pyplot as plt
from numpy import random
from scipy.stats import norm
import numpy as np

# Name: GÖKAY GÜLSOY
# Student No:2 270201072

# function for calculating sample_mean
def calculate_sample_mean(sample_list):
    total = 0
    for i in sample_list:
        total += i

    sample_mean = total / len(sample_list)

    return sample_mean


# function for calculating sample variance and standard deviation
def calculate_sample_variance(sample_list, sample_mean):
    total = 0
    for i in sample_list:
        total += (i - sample_mean) ** 2

    sample_variance = total / (len(sample_list) - 1)

    return sample_variance


# function that makes subplots
def make_subplot(sum_list, mean, standard_deviation, experiment_no, begin, end):
    plt.subplot(2, 3, experiment_no)
    plt.hist(sum_list, bins=100, density=True)
    x_axis = np.arange(begin, end, 0.1)
    plt.plot(x_axis, norm.pdf(x_axis, mean, standard_deviation))
    plt.legend(["normal distribution", "histogram"], loc="upper left")
    plt.title("Experiment " + str(experiment_no))
    plt.xlabel("X-axes")
    plt.ylabel("Y-axes")


# Experiment-1)
# calculating mean and variance for our unifrom distribution function between (0,1)
a = 0
b = 1
# mean is given below (by formula (b+a)/2 for uniform dist.)
mean = (a + b) / 2
# variance is given below (by formula 1/12*(b-a)**2 for uniform dist.)
variance = (1 / 12) * ((1 - 0) ** 2)

# as the number of sums is few we don't expect convergence
# creating 200000 sums
sum_list = []

for i in range(0, 200000):
    x1 = np.random.uniform()
    x2 = np.random.uniform()

    total = x1 + x2
    sum_list.append(total)

# at the end of the for loop sum list will be formed
# theoratical normal distribution has mean and variance given by the following formula
normal_mean = 2 * (mean)
normal_variance = 2 * (variance)
standard_deviation = normal_variance ** (0.5)

# we will skecth normalized histogram and theoratical normal distribution curve
make_subplot(sum_list, normal_mean, standard_deviation, 1, 0, 2)

# Experiment 2-) we will use same probability density function as we used in Experiment-1 for simplicity
# as the number of sums is not a lot we expect partial convergence

# creating 200000 sums
sum_list.clear()

for i in range(0, 200000):
    x1 = np.random.uniform()
    x2 = np.random.uniform()
    x3 = np.random.uniform()
    x4 = np.random.uniform()

    total = x1 + x2 + x3 + x4
    sum_list.append(total)

# theoratical normal distribution has mean and variance given by the following formula
normal_mean = 4 * (mean)
normal_variance = 4 * (variance)
standard_deviation = normal_variance ** (0.5)

# we will skecth normalized histogram and theoratical normal distribution curve
make_subplot(sum_list, normal_mean, standard_deviation, 2, 0, 4)

# Experiment 3-)  we will use same probability density function as we used in Experiment-1 for simplicity
# as all the conditions of central limit theorem is satisfied we expect convergence

# creating 200000 sums again
sum_list.clear()

for i in range(0, 200000):
    total = 0
    for j in range(0, 50):
        x1 = np.random.uniform()
        total += x1

    sum_list.append(total)

# theoratical normal distribution has mean and variance given by the following formula
normal_mean = 50 * (mean)
normal_variance = 50 * (variance)
standard_deviation = normal_variance ** (0.5)

# we will skecth normalized histogram and theoratical normal distribution curve
make_subplot(sum_list, normal_mean, standard_deviation, 3, 17.5, 32.5)

# Experiment-4)
# creating 200000 sums again
sum_list.clear()

# calculating estimated mean and estimated variance for distributions
estimated_mean = 0
estimated_standard_deviation = 0

for i in range(0, 200000):
    total = 0
    dist_count1, dist_count2 = 0, 0
    for j in range(0, 50):
        x1 = np.random.uniform(0, 200)
        x2 = 0

        if (x1 < 99):
            x2 = np.random.uniform(0, 200)
            total += x2

        else:
            x2 = np.random.uniform(98, 102)
            total += x2

    sum_list.append(total)

estimated_mean = calculate_sample_mean(sum_list[0:51])
estimated_standard_deviation = calculate_sample_variance(sum_list[0:51], estimated_mean) ** (0.5)
# as there is a dependence we expect no convergence to normal distribution
# ploting Experiment-4)
make_subplot(sum_list, estimated_mean, estimated_standard_deviation, 4, 4000, 6000)

# Experiment-5) as we are sampling from different distributions again we don't expect convergence
# creating 200000 sums again
sum_list.clear()

# calculating estimated mean and estimated variance for distributions
estimated_mean = 0
estimated_standard_deviation = 0

for i in range(0, 200000):
    total = 0
    for j in range(0, 50):
        x1 = np.random.uniform()
        x2 = np.random.uniform()

        x3 = np.random.uniform(x1, x2 - x1)
        total += x3

    sum_list.append(total)

estimated_mean = calculate_sample_mean(sum_list[0:51])
estimated_standard_deviation = calculate_sample_variance(sum_list[0:51], estimated_mean) ** (0.5)
# ploting Experiment-5)
make_subplot(sum_list, estimated_mean, estimated_standard_deviation, 5, 5, 20)

plt.suptitle("CENTRAL LIMIT THEOREM SIMULATION")
plt.show()
